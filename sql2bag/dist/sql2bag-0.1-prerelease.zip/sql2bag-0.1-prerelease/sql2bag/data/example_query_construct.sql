SELECT TOP 3300 * 
     --this is a comment 
              FROM dbo.Construct ;
